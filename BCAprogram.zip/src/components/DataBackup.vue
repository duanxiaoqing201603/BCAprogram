<template>
  <div >
    数据库备份component
  </div>
</template>
<script>
  export default {
    name:"DataBackup"
  }
</script>
