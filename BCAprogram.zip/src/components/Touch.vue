<template>
  <div >
    触摸校准component
  </div>
</template>
<script>
  export default {
    name:"Touch"
  }
</script>
