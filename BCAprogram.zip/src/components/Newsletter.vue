<template>
  <div >
    通讯检测component
  </div>
</template>
<script>
  export default {
    name:"Newsletter"
  }
</script>
